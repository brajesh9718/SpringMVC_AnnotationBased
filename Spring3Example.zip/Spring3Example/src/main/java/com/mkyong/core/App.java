package com.mkyong.core;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.mkyong.customer.bo.CustomerBo;

@SuppressWarnings("deprecation")
public class App {

	public static void main(String[] args) throws Exception {
		
		//Try To Access AOP feature using BeanFactory to proof concept 
		
		//BeanFactory appContext = new XmlBeanFactory (new ClassPathResource("Spring-Customer.xml"));

		ApplicationContext appContext = new ClassPathXmlApplicationContext("Spring-Customer.xml");
		CustomerBo customer = (CustomerBo) appContext.getBean("customerBo");
		new App().runApp(customer);

	}

	private void runApp(CustomerBo customer) {
		customer.addCustomer();
		/*
		 * System.out.println("-------------------------------"); String obj =
		 * customer.addCustomerReturnValue("addCustomerReturn  Successfully Called");
		 * System.out.println(obj); customer.addMsg();
		 * System.out.println("--------------------------------"); //
		 * customer.addCustomerThrowException(); //
		 * System.out.println("--------------------------------"); String objReturn =
		 * customer.addCustomerAround("mudit");
		 * System.out.println("Return Value in case of AroundAdvice :: " + objReturn);
		 */
	}
}