package com.mkyong.customer.bo.impl;

public class EmployeeDetail {
	public void printEmloyee() {
		System.out.println("Employee is ABC");
	}
}

