package com.mkyong.customer.bo;

public interface CustomerBo {

	void addCustomer();

	String addCustomerReturnValue(String s);

	void addCustomerThrowException() throws Exception;

	String addCustomerAround(String name);

	String addMsg();
	
}