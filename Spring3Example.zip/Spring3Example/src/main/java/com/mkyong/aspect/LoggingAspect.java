package com.mkyong.aspect;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;

@Aspect
public class LoggingAspect {

	/*
	 * @Before("execution(* com.mkyong.customer.bo.CustomerBo.addCustomer(..))")
	 * public void logBefore(JoinPoint joinPoint) {
	 * 
	 * System.out.println("logBefore() is running!");
	 * System.out.println("hijacked : " + joinPoint.getSignature().getName());
	 * System.out.println("******"); }
	 */

	/*
	 * @After("execution(* com.mkyong.customer.bo.CustomerBo.addCustomer(..))")
	 * public void logAfter(JoinPoint joinPoint) {
	 * 
	 * System.out.println("logAfter() is running!");
	 * System.out.println("hijacked : " + joinPoint.getSignature().getName());
	 * System.out.println("******");
	 * 
	 * }
	 */

	/*
	 * @AfterReturning( pointcut =
	 * "execution(* com.mkyong.customer.bo.CustomerBo.addCustomerReturnValue(..))",
	 * returning= "result") public void logAfterReturning(JoinPoint joinPoint,
	 * Object result) {
	 * 
	 * System.out.println("logAfterReturning() is running!");
	 * System.out.println("hijacked : " + joinPoint.getSignature().getName());
	 * System.out.println("Method returned value is : " + result);
	 * System.out.println("******");
	 * 
	 * }
	 */

	/*
	 * @AfterThrowing( pointcut =
	 * "execution(* com.mkyong.customer.bo.CustomerBo.addCustomerThrowException(..))"
	 * , throwing= "error") public void logAfterThrowing(JoinPoint joinPoint,
	 * Throwable error) {
	 * 
	 * System.out.println("logAfterThrowing() is running!");
	 * System.out.println("hijacked : " + joinPoint.getSignature().getName());
	 * System.out.println("Exception : " + error); System.out.println("******");
	 * 
	 * }
	 */

	/*
	 * @Around("execution(* com.mkyong.customer.bo.CustomerBo.addCustomerAround(..))"
	 * ) public void logAround(ProceedingJoinPoint joinPoint) throws Throwable {
	 * 
	 * System.out.println("logAround() is running!");
	 * System.out.println("hijacked method : " +
	 * joinPoint.getSignature().getName());
	 * System.out.println("hijacked arguments : " +
	 * Arrays.toString(joinPoint.getArgs()));
	 * 
	 * System.out.println("Around before is running!"); joinPoint.proceed();
	 * System.out.println("Around after is running!");
	 * 
	 * System.out.println("******");
	 * 
	 * }
	 */

	@Before("beforeAfterPointcut()")
	public void beforeAdvice(JoinPoint jp) {
		System.out.println("Inside Before Advice.... " + jp.getSignature().getName());
	}

	@After("beforeAfterPointcut()")
	public void afterAdvice(JoinPoint jp) {
		System.out.println("Inside Afer Advice.... " + jp.getSignature().getName());
	}

	@Pointcut("execution(* addCustomer(..))")
	public void beforeAfterPointcut() {
	}

	@AfterReturning(pointcut = "execution(String *(String))", returning = "result")
	public void afterReturnningAdvice(String result) {
		System.out.println("afterReturnningAdvice() Running .....  : " + "Result ::" + result);
	}

	@AfterThrowing(pointcut = "execution(* addCustomerThrowException(..))", throwing = "th")
	public void throwingAdvice(Throwable th) {
		System.out.println("ThrowingAdvice Running..." + "Throwing :: " + th);
	}

	@Around("execution(String addCustomerAround(String))")
	public String aroundAdvice(ProceedingJoinPoint jp) {
		System.out.println("aroundAdvice() running ... ");
		Object res = null;
		try {

			res = jp.proceed();
			System.out.println("Result :: " + res);
		} catch (Throwable e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return (String) res;
	}

	@Before("execution(* printEmployee(..))")
	public void beforEmployeeAdvice(){
		System.out.println("Before Advice for Employee Running .....");
	}
	
}