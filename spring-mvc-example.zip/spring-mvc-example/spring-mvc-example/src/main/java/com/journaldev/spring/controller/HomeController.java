package com.journaldev.spring.controller;

import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.ResponseBody;

import com.journaldev.spring.model.User;

@Controller
public class HomeController {

	ArrayList<User> users = new ArrayList<User>();

	/**
	 * Simply selects the home view to render by returning its name.
	 */
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String home(Locale locale, Model model) {
		System.out.println("Home Page Requested, locale = " + locale);
		Date date = new Date();
		DateFormat dateFormat = DateFormat.getDateTimeInstance(DateFormat.LONG, DateFormat.LONG, locale);
		String formattedDate = dateFormat.format(date);
		model.addAttribute("serverTime", formattedDate);
		return "home";
	}

	@RequestMapping(value = "/user", method = RequestMethod.POST)
	public String user(@Validated User user, Model model) {
		System.out.println("User Page Requested");
		model.addAttribute("userName", user.getUserName());
		return "user";
	}
	
	@RequestMapping(value = "/getUserById/{id}" , method = RequestMethod.GET)
	@ResponseBody
	public User getUserById(@PathVariable int id) {
		try {
		User user1 = new User();
		user1.setUid(101);
		user1.setUserName("Ram");
		User user2 = new User();
		user2.setUid(102);
		user2.setUserName("Shyam");
		users.add(user1);
		users.add(user2);
		//Using Jdk1.8 Stream API
		User userObj = users.stream().filter(data -> data.getUid() == id).findFirst().get();
		return userObj;
		}catch (Exception e) {
			System.out.println("Exception occur " + e);
		}
		return null;
	}
}
