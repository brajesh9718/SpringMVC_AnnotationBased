package com.mkyong.customer.bo.impl;

import org.springframework.stereotype.Service;

import com.mkyong.customer.bo.CustomerBo;

@Service
public class CustomerBoImpl implements CustomerBo {

	public void addCustomer() {
		System.out.println("addCustomer() is running ");
	}

	public String addCustomerReturnValue(String s) {
		System.out.println("addCustomerReturnValue() is running ");
		return s;
	}

	public void addCustomerThrowException() throws Exception {
		System.out.println("addCustomerThrowException() is running ");
		throw new Exception("Generic Error");
	}

	public String addCustomerAround(String name) {
		System.out.println("addCustomerAround() is running");
		return name;
	}

	public String addMsg() {
		System.out.println("addMsg() is running...");
		return "Hello Friend";
	}
}